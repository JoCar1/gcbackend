<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Contrato extends Model
{
    use SoftDeletes;
    
    protected $guarded = [];

    protected $dates = ['deleted_at'];

    public function archivos()
    {
        return $this->hasMany('App\Archivo');
    }

    public function links()
    {
        return $this->hasMany('App\Link');
    }

    public function eventos()
    {
        return $this->hasMany('App\Evento');
    }

    public function user()
    {
        return $this->belongsTo('App\User');
    }

    public function organizativaunidad()
    {
        return $this->belongsTo('App\OrganizativaUnidad');
    }

    public function socio()
    {
        return $this->belongsTo('App\Socio');
    }

    public function categoria()
    {
        return $this->belongsTo('App\Categoria');
    }
}
