<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Socio;
use App\Categoria;
use App\Contrato;
use App\OrganizativaUnidad;
use App\User;

class AngularController extends Controller
{
    public function socios()
    {
        $data = Socio::all();
        return response()->json(['data'=>$data], 200); 
    }
    public function categorias()
    {
        $data = Categoria::all();
        return response()->json(['data'=>$data], 200); 
    }

    public function contratos()
    {
        $data = Contrato::all();
        return response()->json(['data'=>$data], 200); 
    }
    public function uorganizativas()
    {
        $data = OrganizativaUnidad::all();
        return response()->json(['data'=>$data], 200); 
    }


    public function usuarios()
    {
        $data = User::all();
        return response()->json(['data'=>$data], 200); 
    }
    
    
}
