<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('login', 'Api\Auth\LoginController@login');

Route::post('refresh', 'Api\Auth\LoginController@refresh');



Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['middleware' => ['auth:api','scope:administrador,editor,visor,apiweb']], function(){

	// auth login regis
	Route::post('logout', 'Api\Auth\LoginController@logout');
	
	Route::resource('usuarios', 'UserController');
	Route::resource('socio', 'SocioController');
	Route::resource('categoria', 'CategoriaController');
	Route::resource('uorganizativa', 'OrganizativaUnidadController');

	Route::get('sociosall', 'AngularController@socios');
	Route::get('categoriasall', 'AngularController@categorias');
	Route::get('contratosall', 'AngularController@contratos');
	Route::get('uorganizativasall', 'AngularController@uorganizativas');
	
	Route::get('usuariosall', 'AngularController@usuarios');

	
});