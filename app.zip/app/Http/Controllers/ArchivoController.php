<?php

namespace App\Http\Controllers;

use App\Archivo;
use Illuminate\Http\Request;
use Carbon\Carbon;

class ArchivoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $request->validate([
            'contrato_id' => 'required',
            'file' => 'required|file'
        ]);
        if(!$request->hasFile('file')) {
            $mensaje = "Archivo no encontrado";
        }else{
            $file = $request->file('file'); 
            $filename = $file->getClientOriginalName();
            $extension = $file->getClientOriginalExtension();
            $fileName = rand(0,10)."-".date('his')."-".rand(0,10).".".$extension;
            $path = 'archivos/';
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            if($file->move($path, $fileName)){
                Archivo::create([
                    'nombre' => $fileName,
                    'url' => 'archivos/'.$fileName,
                    'contrato_id' => $request->contrato_id
                ]);  
            }
            $mensaje = "Registrado correctamente";    
        }
        
        return response()->json(['mensaje'=>$mensaje], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Archivo  $archivo
     * @return \Illuminate\Http\Response
     */
    public function show(Archivo $archivo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Archivo  $archivo
     * @return \Illuminate\Http\Response
     */
    public function edit(Archivo $archivo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Archivo  $archivo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Archivo $archivo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Archivo  $archivo
     * @return \Illuminate\Http\Response
     */
    public function destroy(Archivo $archivo)
    {
        $archivo->delete();
        $mensaje = "Eliminado correctamente";
        return response()->json(['mensaje'=>$mensaje], 200);

    }
}
