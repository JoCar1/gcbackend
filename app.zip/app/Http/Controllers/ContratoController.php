<?php

namespace App\Http\Controllers;

use App\Contrato;
use App\Archivo;
use App\Evento;
use App\Email;
use App\User;
use App\Socio;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use DB;

class ContratoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //usar rando 10 
        $limit = $request->get('limit');
        //Order
        $columna = $request->get('columna');
        $order = $request->get('order');
        $filter = $request->get('filter');
        $ff = $request->get('ff', $filter==''?'%%':'%'.$filter.'%');

        // if($columna == 'socio')
        switch ($columna) {
            case 'socio':
                $data = Contrato::whereHas('socio', function ($query) use ($columna,$ff) {
                    $query->where('nombre', 'like', $ff);
                })
                ->orderBy('socio_id',$order)->paginate($limit);
                break;
            case 'categoria':
                $data = Contrato::whereHas('categoria', function ($query) use ($columna,$ff) {
                    $query->where('nombre', 'like', $ff);
                })
                ->orderBy('categoria_id',$order)->paginate($limit);
                break;
            default:
                $data = Contrato::where($columna, 'like', $ff)
                ->orderBy($columna,$order)->paginate($limit);
                break;
        }

        
        foreach ($data as $key => $value) {
            $value->socio;
            $value->categoria;
            $value->user;
            $value['responsable'] = User::find($value->responsable_contrato_user_id);
            $value->organizativaunidad;
            foreach ($value->archivos as $ky => $val) {
                $val->url = asset($val->url);
            }
        }
        return response()->json(['data'=>$data], 200); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'socio_id' => 'required|max:255',
            'categoria_id' => 'required',
            'nombre' => 'required|string',
            'estado' => 'required|string',
            'fecha_inicio' => 'required|string',
            'estado' => 'required|string',
            'responsable_contrato_user_id' => 'required',
            'organizativa_unidad_id' => 'required'
        ]);
        $data = $request->all();
        // DB::beginTransaction();
        $contrato = Contrato::create([
            'socio_id' => $data['socio_id'],
            'user_id' => Auth::user()->id,
            'categoria_id' => $data['categoria_id'],
            'contrato_id' => $data['contrato_id'],
            'nombre' => $data['nombre'],
            'estado' => $data['estado'],
            'telefono' => $data['telefono'],
            'descripcion' => $data['descripcion'],
            'fecha_inicio' => $data['fecha_inicio'],
            'fecha_plazo_cancelacion' => $data['fecha_plazo_cancelacion'],
            'fecha_fin' => $data['fecha_fin'],
            'fecha_prolongacion' => $data['fecha_prolongacion'],
            'responsable_contrato_user_id' => $data['responsable_contrato_user_id'],
            'organizativa_unidad_id' => $data['organizativa_unidad_id'],
            'contacto_adicional' => $data['contacto_adicional']
        ]);
        //crear evento fechas
        

        if($data['fecha_inicio']){
            $eventoi = Evento::create([
                'nombre' => 'Inicio del contrato',
                'descripcion' => 'Inicio del contrato',
                'fecha_evento' => $data['fecha_inicio'],
                'fecha_recordatorio' => Carbon::parse($data['fecha_inicio'])->addDays(-2),
                'notificacion' => '1',
                'frecuencia_notificacion' => 'd',
                'frecuencia_notificacion_cantidad' => 1,
                'envio_email' => '1',
                'frecuencia_email' => 'd',
                'frecuencia_email_cantidad' => 1,
                'contrato_id' => $contrato->id,
                'count_notificacion' => 1,
                'count_email' => 1

            ]); 
            if($contrato->socio->email){
                Email::create([
                    'email' => $contrato->socio->email,
                    'evento_id' => $eventoi->id
                ]);
            }
            if($contrato->user->email){
                Email::create([
                    'email' => $contrato->user->email,
                    'evento_id' => $eventoi->id
                ]);
            }
            $userres = User::find($data['responsable_contrato_user_id']);
            if($userres->email != $contrato->user->email){
                Email::create([
                    'email' => $userres->email,
                    'evento_id' => $eventoi->id
                ]);
            } 
        }
        if($data['fecha_plazo_cancelacion']){
            $eventoc = Evento::create([
                'nombre' => 'Cancelación del contrato',
                'descripcion' => 'Cancelación del contrato',
                'fecha_evento' => $data['fecha_plazo_cancelacion'],
                'fecha_recordatorio' => Carbon::parse($data['fecha_plazo_cancelacion'])->addDays(-2),
                'notificacion' => '1',
                'frecuencia_notificacion' => 'd',
                'frecuencia_notificacion_cantidad' => 1,
                'envio_email' => '1',
                'frecuencia_email' => 'd',
                'frecuencia_email_cantidad' => 1,
                'contrato_id' => $contrato->id,
                'count_notificacion' => 1,
                'count_email' => 1

            ]); 
            if($contrato->socio->email){
                Email::create([
                    'email' => $contrato->socio->email,
                    'evento_id' => $eventoc->id
                ]);
            }
            if($contrato->user->email){
                Email::create([
                    'email' => $contrato->user->email,
                    'evento_id' => $eventoc->id
                ]);
            }
            $userres = User::find($data['responsable_contrato_user_id']);
            if($userres->email != $contrato->user->email){
                Email::create([
                    'email' => $userres->email,
                    'evento_id' => $eventoc->id
                ]);
            } 
        }
        if($data['fecha_fin']){
            $eventof = Evento::create([
                'nombre' => 'Fin del contrato',
                'descripcion' => 'Fin del contrato',
                'fecha_evento' => $data['fecha_fin'],
                'fecha_recordatorio' => Carbon::parse($data['fecha_fin'])->addDays(-2),
                'notificacion' => '1',
                'frecuencia_notificacion' => 'd',
                'frecuencia_notificacion_cantidad' => 1,
                'envio_email' => '1',
                'frecuencia_email' => 'd',
                'frecuencia_email_cantidad' => 1,
                'contrato_id' => $contrato->id,
                'count_notificacion' => 1,
                'count_email' => 1

            ]);
            if($contrato->socio->email){
                Email::create([
                    'email' => $contrato->socio->email,
                    'evento_id' => $eventof->id
                ]);
            }
            if($contrato->user->email){
                Email::create([
                    'email' => $contrato->user->email,
                    'evento_id' => $eventof->id
                ]);
            }
            $userres = User::find($data['responsable_contrato_user_id']);
            if($userres->email != $contrato->user->email){
                Email::create([
                    'email' => $userres->email,
                    'evento_id' => $eventof->id
                ]);
            } 
        }
        if($data['fecha_prolongacion']){
            $eventop = Evento::create([
                'nombre' => 'Prolongación del contrato',
                'descripcion' => 'Prolongación del contrato',
                'fecha_evento' => $data['fecha_prolongacion'],
                'fecha_recordatorio' => Carbon::parse($data['fecha_prolongacion'])->addDays(-2),
                'notificacion' => '1',
                'frecuencia_notificacion' => 'd',
                'frecuencia_notificacion_cantidad' => 1,
                'envio_email' => '1',
                'frecuencia_email' => 'd',
                'frecuencia_email_cantidad' => 1,
                'contrato_id' => $contrato->id,
                'count_notificacion' => 1,
                'count_email' => 1
            ]); 
            if($contrato->socio->email){
                Email::create([
                    'email' => $contrato->socio->email,
                    'evento_id' => $eventop->id
                ]);
            }
            if($contrato->user->email){
                Email::create([
                    'email' => $contrato->user->email,
                    'evento_id' => $eventop->id
                ]);
            }
            $userres = User::find($data['responsable_contrato_user_id']);
            
            if($userres->email != $contrato->user->email){
                Email::create([
                    'email' => $userres->email,
                    'evento_id' => $eventop->id
                ]);
            }
        }
        //emails
        

        $mensaje = "Registrado correctamente";
        return response()->json(['mensaje'=>$mensaje,'id'=>$contrato->id], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Contrato  $contrato
     * @return \Illuminate\Http\Response
     */
    public function show(Contrato $contrato)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Contrato  $contrato
     * @return \Illuminate\Http\Response
     */
    public function edit(Contrato $contrato)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Contrato  $contrato
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Contrato $contrato)
    {
        $request->validate([
            'socio_id' => 'required|max:255',
            'categoria_id' => 'required',
            'nombre' => 'required|string',
            'estado' => 'required|string',
            'fecha_inicio' => 'required|string',
            'estado' => 'required|string',
            'responsable_contrato_user_id' => 'required',
            'organizativa_unidad_id' => 'required'
        ]);
        $data = $request->all();
        $contrato->socio_id = $data['socio_id'];
        $contrato->categoria_id = $data['categoria_id'];
        $contrato->contrato_id = $data['contrato_id'];
        $contrato->nombre = $data['nombre'];
        $contrato->estado = $data['estado'];
        $contrato->telefono = $data['telefono'];
        $contrato->descripcion = $data['descripcion'];
        $contrato->fecha_inicio = $data['fecha_inicio'];
        $contrato->fecha_plazo_cancelacion = $data['fecha_plazo_cancelacion'];
        $contrato->fecha_fin = $data['fecha_fin'];
        $contrato->fecha_prolongacion = $data['fecha_prolongacion'];
        $contrato->responsable_contrato_user_id = $data['responsable_contrato_user_id'];
        $contrato->organizativa_unidad_id = $data['organizativa_unidad_id'];
        $contrato->contacto_adicional = $data['contacto_adicional'];
        $contrato->update();
        //
        // query eliminar todos los eventos relacionos en un solo query
        Evento::where('contrato_id', $contrato->id)->delete();
        //crear evento fechas

        if($data['fecha_inicio']){
            $eventoi = Evento::create([
                'nombre' => 'Inicio del contrato',
                'descripcion' => 'Inicio del contrato',
                'fecha_evento' => $data['fecha_inicio'],
                'fecha_recordatorio' => Carbon::parse($data['fecha_inicio'])->addDays(-2),
                'notificacion' => '1',
                'frecuencia_notificacion' => 'd',
                'frecuencia_notificacion_cantidad' => 1,
                'envio_email' => '1',
                'frecuencia_email' => 'd',
                'frecuencia_email_cantidad' => 1,
                'contrato_id' => $contrato->id,
                'count_notificacion' => 1,
                'count_email' => 1

            ]); 
            if($contrato->socio->email){
                Email::create([
                    'email' => $contrato->socio->email,
                    'evento_id' => $eventoi->id
                ]);
            }
            if($contrato->user->email){
                Email::create([
                    'email' => $contrato->user->email,
                    'evento_id' => $eventoi->id
                ]);
            }
            $userres = User::find($data['responsable_contrato_user_id']);
            if($userres->email != $contrato->user->email){
                Email::create([
                    'email' => $userres->email,
                    'evento_id' => $eventoi->id
                ]);
            } 
        }
        if($data['fecha_plazo_cancelacion']){
            $eventoc = Evento::create([
                'nombre' => 'Cancelación del contrato',
                'descripcion' => 'Cancelación del contrato',
                'fecha_evento' => $data['fecha_plazo_cancelacion'],
                'fecha_recordatorio' => Carbon::parse($data['fecha_plazo_cancelacion'])->addDays(-2),
                'notificacion' => '1',
                'frecuencia_notificacion' => 'd',
                'frecuencia_notificacion_cantidad' => 1,
                'envio_email' => '1',
                'frecuencia_email' => 'd',
                'frecuencia_email_cantidad' => 1,
                'contrato_id' => $contrato->id,
                'count_notificacion' => 1,
                'count_email' => 1

            ]); 
            if($contrato->socio->email){
                Email::create([
                    'email' => $contrato->socio->email,
                    'evento_id' => $eventoc->id
                ]);
            }
            if($contrato->user->email){
                Email::create([
                    'email' => $contrato->user->email,
                    'evento_id' => $eventoc->id
                ]);
            }
            $userres = User::find($data['responsable_contrato_user_id']);
            if($userres->email != $contrato->user->email){
                Email::create([
                    'email' => $userres->email,
                    'evento_id' => $eventoc->id
                ]);
            } 
        }
        if($data['fecha_fin']){
            $eventof = Evento::create([
                'nombre' => 'Fin del contrato',
                'descripcion' => 'Fin del contrato',
                'fecha_evento' => $data['fecha_fin'],
                'fecha_recordatorio' => Carbon::parse($data['fecha_fin'])->addDays(-2),
                'notificacion' => '1',
                'frecuencia_notificacion' => 'd',
                'frecuencia_notificacion_cantidad' => 1,
                'envio_email' => '1',
                'frecuencia_email' => 'd',
                'frecuencia_email_cantidad' => 1,
                'contrato_id' => $contrato->id,
                'count_notificacion' => 1,
                'count_email' => 1

            ]);
            if($contrato->socio->email){
                Email::create([
                    'email' => $contrato->socio->email,
                    'evento_id' => $eventof->id
                ]);
            }
            if($contrato->user->email){
                Email::create([
                    'email' => $contrato->user->email,
                    'evento_id' => $eventof->id
                ]);
            }
            $userres = User::find($data['responsable_contrato_user_id']);
            if($userres->email != $contrato->user->email){
                Email::create([
                    'email' => $userres->email,
                    'evento_id' => $eventof->id
                ]);
            } 
        }
        if($data['fecha_prolongacion']){
            $eventop = Evento::create([
                'nombre' => 'Prolongación del contrato',
                'descripcion' => 'Prolongación del contrato',
                'fecha_evento' => $data['fecha_prolongacion'],
                'fecha_recordatorio' => Carbon::parse($data['fecha_prolongacion'])->addDays(-2),
                'notificacion' => '1',
                'frecuencia_notificacion' => 'd',
                'frecuencia_notificacion_cantidad' => 1,
                'envio_email' => '1',
                'frecuencia_email' => 'd',
                'frecuencia_email_cantidad' => 1,
                'contrato_id' => $contrato->id,
                'count_notificacion' => 1,
                'count_email' => 1
            ]); 
            if($contrato->socio->email){
                Email::create([
                    'email' => $contrato->socio->email,
                    'evento_id' => $eventop->id
                ]);
            }
            if($contrato->user->email){
                Email::create([
                    'email' => $contrato->user->email,
                    'evento_id' => $eventop->id
                ]);
            }
            $userres = User::find($data['responsable_contrato_user_id']);
            
            if($userres->email != $contrato->user->email){
                Email::create([
                    'email' => $userres->email,
                    'evento_id' => $eventop->id
                ]);
            }
        }
        //emails
        

        $mensaje = "Actualizado correctamente";
        return response()->json(['mensaje'=>$mensaje,'id'=>$contrato->id], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Contrato  $contrato
     * @return \Illuminate\Http\Response
     */
    public function destroy(Contrato $contrato)
    {
        //
    }
}
