<?php

namespace App\Exports;

use App\Contrato;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ContratosExport implements ShouldAutoSize, FromCollection, WithMapping, WithHeadings
{
    public function headings(): array
    {
        return [
            'Nombre contrato',
            'Socio',
            'Creado por',
            'Categoria',
            'estado',
            'Telefono',
            'Descripcion',
            'Fecha inicio',
            'Fecha plazo de cancelacion',
            'Fecha fin',
            'Fecha prolongacion',
            'Responsable',
            'Unidad Organizativa',
            'Contacto adicional',
            'Fecha de creacion',
        ];
    }
    /**
    * @return \Illuminate\Support\Collection
    */

    public function map($contrato): array
    {
        return [
            $contrato->nombre,
            $contrato->socio->nombre,
            $contrato->user->nombre,
            $contrato->categoria->nombre,
            $contrato->estado,
            $contrato->telefono,
            $contrato->descripcion,
            $contrato->fecha_inicio,
            $contrato->fecha_plazo_cancelacion,
            $contrato->fecha_fin,
            $contrato->fecha_prolongacion,
            $contrato->responsablecontrato->nombre,
            $contrato->organizativaunidad->nombre,
            $contrato->contacto_adicional,
            $contrato->created_at,
            // Date::dateTimeToExcel($contrato->created_at),
        ];
    }
    public function collection()
    {
        return Contrato::all();
    }
}
