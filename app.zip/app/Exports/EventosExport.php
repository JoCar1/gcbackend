<?php

namespace App\Exports;

use App\Evento;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;

class EventosExport implements ShouldAutoSize, FromCollection, WithMapping, WithHeadings
{
    public function headings(): array
    {
        return [
            'Nombre evento',
            'Descripcion',
            'Fecha evento',
            'Fecha recordatorio',
            'Notificacion',
            'Frecuencia notificacion',
            'Frecuencia notificacion cantidad',
            'Envio email',
            'Frecuencia email',
            'Frecuencia email cantidad',
            'Contrato',
            'Creado'
        ];
    }
    /**
    * @return \Illuminate\Support\Collection
    */

    public function map($evento): array
    {
        return [
            $evento->nombre,
            $evento->descripcion,
            $evento->fecha_evento,
            $evento->fecha_recordatorio,
            $evento->notificacion,
            $evento->frecuencia_notificacion,
            $evento->frecuencia_notificacion_cantidad,
            $evento->envio_email,
            $evento->frecuencia_email,
            $evento->frecuencia_email_cantidad,
            $evento->contrato->nombre,
            $evento->created_at
            // Date::dateTimeToExcel($contrato->created_at),
        ];
    }
    public function collection()
    {
        return Evento::all();
    }
}
